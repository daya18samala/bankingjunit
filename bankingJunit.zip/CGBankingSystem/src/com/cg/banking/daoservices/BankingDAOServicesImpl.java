package com.cg.banking.daoservices;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
public class BankingDAOServicesImpl implements BankingDAOServices{
	
	private static Customer[] customerList=new Customer[10];
	private static int CUSTOMER_ID_COUNTER=111;
	private static int CUSTOMER_IDX_COUNTER=0;
	
	public int insertCustomer(Customer customer) {
		if(CUSTOMER_IDX_COUNTER>=0.7*customerList.length) {
			Customer[] temp=new Customer[customerList.length+10];
			System.arraycopy(customerList, 0, temp, 0, CUSTOMER_IDX_COUNTER);
			customerList=temp;
		}
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_ID_COUNTER++]=customer;
		return customer.getCustomerId();
	}
		
	public long insertAccount(int customerId,Account account) {
		
	}
		
	

}




